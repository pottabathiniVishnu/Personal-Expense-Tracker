from django.apps import AppConfig


class ExpenseManagerConfig(AppConfig):
    name = 'expense_manager'
